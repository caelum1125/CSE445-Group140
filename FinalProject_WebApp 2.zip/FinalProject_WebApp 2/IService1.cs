﻿using System.ServiceModel;

namespace PasswordGenerator
{
    [ServiceContract]
    public interface IService1
    {
        [OperationContract]
        string GeneratePassword();
    }
}
