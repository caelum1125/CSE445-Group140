﻿using System;
using System.Web.UI;

namespace FinalProject_WebApp
{
    public partial class MemberWelcome : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Member"] == null)
            {
                Response.Redirect("MemberLogin.aspx");
            }
        }
    }
}
