﻿using System;
using System.Data;
using FinalProject_WebApp.AuthServiceRef1;
using System.Web;
using FinalProject_WebApp;
using System.Web.UI;
using System.Web.UI.HtmlControls;

namespace FinalProject_WebApp
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Populate dropdown from cookie
                ddlTheme.SelectedValue = CookieHelper.GetTheme(Request);

                // Build Service Directory table
                BuildDirectoryTable();
            }
        }

        private void BuildDirectoryTable()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Provider");
            dt.Columns.Add("Component Type");
            dt.Columns.Add("Name / Link");
            dt.Columns.Add("Inputs");
            dt.Columns.Add("Outputs");
            dt.Columns.Add("Description");

            // Member A Components
            dt.Rows.Add("Caelum Terrell", "Integration", "Default.aspx (Service Directory, Theme, Password Try-It)", "—", "—", "Built homepage integrating services, components, and demos together.");

            dt.Rows.Add("Caelum Terrell", "Global.asax", "Hit-counter", "—", "—",
                "Application_Start & Session_Start increment visitor count");
            dt.Rows.Add("Caelum Terrell", "Cookie Helper", "ThemeColor cookie", "color(string)",
                "none", "Stores selected theme for 14 days");
            dt.Rows.Add("Caelum Terrell", "Web Service",
                $"<a href='AuthUtilityService.asmx' target='_blank'>AuthUtilityService (CheckStrength)</a>",
                "password(string)", "score(int)", "Returns 0‑4 password strength score");

            // Member B Components
            dt.Rows.Add("Chase Sondrup", "Web Service", $"<a href='Service1.svc' target='_blank'>GeneratePassword Web Service (Service1.svc)</a>", "—", "password(string)", "Generates a random password");

            dt.Rows.Add("Chase Sondrup", "DLL",
                $"<a href='DLLTryIt.aspx' target='_blank'>DLLTryIt (SecurityLibrary)</a>",
                "input(string), key(string)", "hash/encrypted/decrypted string",
                "Hashing and AES encryption functions");

            // Member C Components
            dt.Rows.Add("Ty Stinson", "User Control",
                "WelcomeMessage.ascx", "Session[\"Member\"]", "Welcome Text",
                "Displays welcome greeting for logged-in user");

            dt.Rows.Add("Chase Sondrup", "Captcha Try-It",
                $"<a href='CaptchaTryIt.aspx' target='_blank'>CaptchaTryIt.aspx</a>",
                "captcha text", "success/fail", "Validates CAPTCHA user input");

            dt.Rows.Add("Chase Sondrup", "Member Pages",
                $"<a href='Register.aspx' target='_blank'>Register.aspx</a> / <a href='MemberLogin.aspx' target='_blank'>MemberLogin.aspx</a>",
                "username/password", "login success/failure",
                "Self-register and login into Member portal");

            dt.Rows.Add("Ty Stinson", "Reverse String Try-It",
                $"<a href='RSTryIt.aspx' target='_blank'>RSTryIt.aspx</a>",
                "string", "reversed string",
                "Reverses user input string using Web Service");

            dt.Rows.Add("Ty Stinson", "Staff Management",
                $"<a href='Staff.aspx' target='_blank'>Staff.aspx</a>",
                "username/password", "staff records updated",
                "Add/View staff users, encrypt passwords");

            tblDirectory.Text = ToHtml(dt);
        }

        private static string ToHtml(DataTable dt)
        {
            var sb = new System.Text.StringBuilder();
            sb.Append("<table style='border-collapse: collapse; width: 100%;'>");
            sb.Append("<thead><tr>");
            foreach (DataColumn col in dt.Columns)
            {
                sb.Append($"<th style='border: 1px solid #ccc; padding: 8px; background: #f2f2f2;'>{col.ColumnName}</th>");
            }
            sb.Append("</tr></thead>");
            sb.Append("<tbody>");
            foreach (DataRow row in dt.Rows)
            {
                sb.Append("<tr>");
                foreach (var cell in row.ItemArray)
                {
                    sb.Append($"<td style='border: 1px solid #ccc; padding: 8px;'>{cell}</td>");
                }
                sb.Append("</tr>");
            }
            sb.Append("</tbody>");
            sb.Append("</table>");
            return sb.ToString();
        }


        /*** Button Handlers ***/

        protected void BtnCheck_Click(object sender, EventArgs e)
        {
            var svc = new AuthUtilityService();
            int score = svc.CheckStrength(txtPwd.Text);
            lblScore.Text = $"Strength = {score}";
        }

        protected void BtnSaveTheme_Click(object sender, EventArgs e)
        {
            CookieHelper.SetTheme(Response, ddlTheme.SelectedValue);
            lblThemeMsg.Text = "Cookie saved! Refresh the page to see it persist.";
        }
    }
}
